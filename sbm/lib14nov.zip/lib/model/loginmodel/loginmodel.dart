class Loginmassege {
  bool? success;
  LoginDataRespons? data;
  String? message;

  Loginmassege({this.success, this.data, this.message});

  Loginmassege.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    data = json['data'] != null ? new LoginDataRespons.fromJson(json['data']) : null;
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['success'] = this.success;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    data['message'] = this.message;
    return data;
  }
}

class LoginDataRespons {
  String? token;
  int? id;
  String? email;
  String? name;
  String? firstName;
  String? lastName;
  int? userRole;
  String? profilepic;

  LoginDataRespons(
      {this.token,
        this.id,
        this.email,
        this.name,
        this.firstName,
        this.lastName,
        this.userRole,
        this.profilepic});

  LoginDataRespons.fromJson(Map<String, dynamic> json) {
    token = json['token'];
    id = json['id'];
    email = json['email'];
    name = json['name'];
    firstName = json['first_name'];
    lastName = json['last_name'];
    userRole = json['user_role'];
    profilepic = json['profilepic'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['token'] = this.token;
    data['id'] = this.id;
    data['email'] = this.email;
    data['name'] = this.name;
    data['first_name'] = this.firstName;
    data['last_name'] = this.lastName;
    data['user_role'] = this.userRole;
    data['profilepic'] = this.profilepic;
    return data;
  }
}