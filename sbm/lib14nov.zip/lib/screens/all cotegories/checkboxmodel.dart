class MultiselectCheckbox {
  String? title;
  MultiselectCheckbox({
    this.title,
  });
}
